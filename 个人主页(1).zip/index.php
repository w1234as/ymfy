<?php
  if (isset($_GET['password'])){
    $pass = $_GET['password'];
    $json = '{"code" : 1 , "href" : "gly.html"}';
    if ($pass == "080618"){
      echo $json;
    }else{
      echo "\u5BC6\u7801\u9519\u8BEF";
    }
  }else{
    echo "\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A";
  }
    
?>