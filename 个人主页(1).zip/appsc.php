<?php
    $name = $_GET['name'];
    // 文件路径
    $filePath = 'json.txt';
    // 要删除的行中包含的文本
    $textToRemove = $name;

    // 读取文件内容到数组，每个元素代表一行
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // 遍历每一行，找到要删除的行
    foreach ($lines as $index => $line) {
        if (strpos($line, $textToRemove) !== false) {
            // 找到后，从数组中移除该行
            unset($lines[$index]);
            break; // 如果只需要删除找到的第一行，就退出循环
        }
}

    // 将剩余的行写回文件
    file_put_contents($filePath, implode(PHP_EOL, $lines));
?>