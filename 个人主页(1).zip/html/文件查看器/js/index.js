      var input1 = document.getElementById("input1");
      var btn = document.getElementById("btn");
      var div1 = document.getElementById("div1");
      var div2 = document.getElementById("div2");
      var div3 = document.getElementById("div3");
      var btn3 = document.getElementById("btn3");
      var div4 = document.getElementById("div4");
      
      function ok(){
        var files = input1.files;
        for(i = 0;i < files.length;i++){
          var file = files[i];
          if (file.type.startsWith('image/')) {
            div1.innerHTML = "";
            var imgs = document.createElement("img");
            div1.appendChild(imgs);
            imgs.src = URL.createObjectURL(file);
            btn3.onclick=function (){
              window.location.href=imgs.src;
            }
        }
      
      
        else if(file.type.startsWith('video/')) {
            div1.innerHTML = "";
            var imgs = document.createElement("video");
            div1.appendChild(imgs);
            imgs.src = URL.createObjectURL(file);
            imgs.controls = true;
            btn3.onclick=function (){
              alert("视频无法放大，请从视频中选择全屏");
            }
         }
       
       
         else if(file.type.startsWith('audio/')) {
            div1.innerHTML = "";
            var imgs = document.createElement("audio");
            div1.appendChild(imgs);
            imgs.src = URL.createObjectURL(file);
            imgs.controls = true;
            btn3.onclick=function (){
              alert("音频只能听，暂时无法查看");
            }
         }
       
       
       else if(file.type.startsWith('text/html')) {
             var alerts = confirm("该为html文件，是否渲染该页面？");
             if(alerts == true){
               div1.innerHTML = "";
               var reader = new FileReader();
               var filediv = document.createElement("div");
               reader.onload = function(e) {
               filediv.innerHTML = e.target.result;
               div1.appendChild(filediv);
               btn3.onclick=function (){
                 alert("该文件无法放大");
               }
             };
             reader.readAsText(file);
             }else{
               div1.innerHTML = "";
               var reader = new FileReader();
               var filediv = document.createElement("xmp");
               reader.onload = function(e) {
               filediv.innerHTML = e.target.result;
               div1.appendChild(filediv);
               filediv.style.overflow = "auto";
               btn3.onclick=function (){
                 //alert("该文件无法放大");
                 filediv.style.fontSize = "20px";
               }
             };
             reader.readAsText(file);
             }
           

          }
       else if(file.type.startsWith('text/')) {
             div1.innerHTML = "";
             var reader = new FileReader();
             var filediv = document.createElement("xmp");
             reader.onload = function(e) {
              filediv.innerHTML = e.target.result;
              div1.appendChild(filediv);
              filediv.style.overflow = "auto";
              btn3.onclick=function (){
                //alert("该文件无法放大");
                filediv.style.fontSize = "20px";
              }
             };
             reader.readAsText(file);
          }
        
        
          else{
            div1.innerHTML = "<h3>该文件暂时无法查看…</h3>";
        }
      }
    };
input1.addEventListener("change",function(){
      ok();
    });
  