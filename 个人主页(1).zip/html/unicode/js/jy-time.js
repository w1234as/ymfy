var jy = {
   "时分秒" : function times(obj,obj2){
     var objinnerHTML = document.getElementById(obj);
     var datetime = new Date();
     var TimeH = datetime.getHours();
     var TimeM = datetime.getMinutes();
     var TimeS = datetime.getSeconds();
     if(obj2 == null || obj2 == ""){
       objinnerHTML.innerHTML = TimeH + "：" + TimeM + "：" + TimeS;
     }else{
       objinnerHTML.innerHTML = TimeH + "时" + TimeM + "分" + TimeS + "秒";
     }
   },
   "年月日" : function (obj,obj2){
     var objinnerHTML = document.getElementById(obj);
     var datetime = new Date();
     var TimeFullYear = datetime.getFullYear();
     var TimeMonth = datetime.getMonth() + 1;
     var TimeDate = datetime.getDate();
     if(obj2 == null || obj2 == ""){
       objinnerHTML.innerHTML = TimeFullYear + "-" + TimeMonth + "-" + TimeDate;
     }else{
       objinnerHTML.innerHTML = TimeFullYear + "年" + TimeMonth + "月" + TimeDate + "日";
     }
   },
   //obj:Id，obj1:年，月，日，时，分，秒
   "历史到今天" : function (obj,obj1){
     var objinnerHTML = document.getElementById(obj);
     var datetime = new Date();
     var TimeH = datetime.getHours();
     var TimeM = datetime.getMinutes();
     var TimeS = datetime.getSeconds();
     var TimeFullYear = datetime.getFullYear();
     var TimeMonth = datetime.getMonth();
     var TimeDate = datetime.getDate();
     var Time = obj1.split(",")
     var A = Number(TimeFullYear) - Number(Time[0]);//年
     var B = Number(TimeMonth) - Number(Time[1]) + 1;//月
     var C = Number(TimeDate) - Number(Time[2]);//日
     var D = Number(TimeH) - Number(Time[3]);//时
     var E = Number(TimeM) - Number(Time[4]);//分
     var F = Number(TimeS) - Number(Time[5]);//秒
     if(A < 0){
       var A = 0;
       var C = Math.abs(C);
       var D = Math.abs(D);
       var E = Math.abs(E);
       var F = Math.abs(F);
       objinnerHTML.innerHTML = A + "年" + B + "月" + C + "日" + D + "时" + E + "分" + F + "秒";
       if(B < 0){
         var B = 30 - Math.abs(B);
         var C = Math.abs(C);
         var D = Math.abs(D);
         var E = Math.abs(E);
         var F = Math.abs(F);
         objinnerHTML.innerHTML = A + "年" + B + "月" + C + "日" + D + "时" + E + "分" + F + "秒";

       }
     }
     else if(B < 0){
       var B = 0;
       var C = Math.abs(C);
     var D = Math.abs(D);
     var E = Math.abs(E);
     var F = Math.abs(F);
     objinnerHTML.innerHTML = A + "年" + B + "月" + C + "日" + D + "时" + E + "分" + F + "秒";

     }else{
     //var A = Math.abs(A);
     //var B = Math.abs(B);
     var C = Math.abs(C);
     var D = Math.abs(D);
     var E = Math.abs(E);
     var F = Math.abs(F);
     objinnerHTML.innerHTML = A + "年" + B + "月" + C + "日" + D + "时" + E + "分" + F + "秒";
     }
   },
 };