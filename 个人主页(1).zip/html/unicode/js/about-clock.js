const canvas = document.getElementById('clock');
    const ctx = canvas.getContext('2d');

    function drawClock() {
        // 清除之前的绘制
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 将原点移动到中心，并旋转90度，使12点方向朝上
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(-Math.PI / 2); // 逆时针旋转90度

        // 绘制时钟背景
        const radius = Math.min(centerX, centerY) - 10;
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, 2 * Math.PI);
        ctx.stroke();

        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        const seconds = now.getSeconds();

        // 绘制时针
        drawHand(0, 0, radius * 0.4, (hours % 12) * 30 + minutes / 2);

        // 绘制分针
        drawHand(0, 0, radius * 0.6, minutes * 6);

        // 绘制秒针
        drawHand(0, 0, radius * 0.8, seconds * 6, 'red');

        ctx.restore();

        // 每秒更新时钟
        requestAnimationFrame(drawClock);
    }

    function drawHand(cx, cy, length, angle, color = 'black') {
        // 将角度转换为弧度
        const angleInRadians = angle * Math.PI / 180;

        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + length * Math.cos(angleInRadians),
                   cy + length * Math.sin(angleInRadians));
        ctx.stroke();
    }

    drawClock();