function ok(){
    document.getElementById("jine")
    let je = prompt("请输入你要修改的金额：")
    if(je == 0){
      jine.innerHTML = "¥0.00"
    }
  else{
      jine.innerHTML = "¥" + je
    }
  }
function dc(){
    wc.exit()
    }