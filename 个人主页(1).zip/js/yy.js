      //设置变量
      var yy = document.getElementById("yy");
      var yycreate = true;
      //初始化ajax
      var yyajax = new XMLHttpRequest();
      //请求成功
      var i = 0;
      yyajax.onreadystatechange = function() {
          //获取数据
          var yytext = this.responseText;
          //转数组
          var yytext2 = yytext.split("\n");
          //循环
          while (true) {
              //转json
              var yytext3 = JSON.parse(yytext2[i]);
              //获取对象值
              var yytext4 = yytext3.name;
              var yytext5 = yytext3.href;
              //创建div
              var yydiv = document.createElement("div");
              var yya = document.createElement("a");
              //设置内容
              yydiv.textContent = yytext4;
              yya.textContent = "立即下载";
              //设置下载链接
              yya.href = yytext5;
              //设置class类名
              yydiv.className = "yydiv1";
              yya.className = "yya1";
              //插入
              yy.appendChild(yydiv);
              yydiv.appendChild(yya);
              //判断是否全部创建完毕
              if (i >= yytext2.length) {
                  break; //停止循环
              } else {
                  i++; //继续增加
              }
          }
      }
      yyajax.open('GET', 'json.txt'); //路径
      yyajax.send(); //发送请求