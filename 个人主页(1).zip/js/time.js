//设置时间函数
var yimo = {
  "Time" : function (obj,obj1){
    //时间(Time)
    var date = new Date()
    //获取年月日
    var Nian = date.getFullYear();
    var Yue = date.getMonth() + 1;
    var Ri = date.getDate();
    var NYR = Nian + "-" + Yue + "-" + Ri;
    //获取时分秒
    var Shi = date.getHours();
    var Fen = date.getMinutes();
    var Miao = date.getSeconds();
    var SFM = Shi + ":" + Fen + ":" + Miao;
    obj.innerHTML = NYR;
    obj1.innerHTML = SFM;
  }
}