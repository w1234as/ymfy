      //设置时间
      var year = document.getElementById("year");
      var hours = document.getElementById("hours");
      yimo.Time(year,hours);
      setInterval(function (){
        yimo.Time(year,hours);
      },1000)
      
      //ID获取
      var syks = document.getElementById("syks");
      var syqq = document.getElementById("syqq");
      var sywx = document.getElementById("sywx");
      var div6 = document.getElementById("div6");
      var alertp1 = document.getElementById("alertp1");
      var alerth1 = document.getElementById("alerth1");
      var alertdiv3 = document.getElementById("alertdiv3");
      var alertdiv4 = document.getElementById("alertdiv4");
      
      //初始化clipboard.js
      var clipboard = new ClipboardJS('.alertdiv3',{
        text:function (){
          return alerth1.innerHTML;//复制内容
        }
      });
      //剪切板监听
      clipboard.on('success',function (e){
        alert("复制成功");
        e.clearSelection();//清除选择
      })
      clipboard.on('error',function (e){
        alert("复制失败");
      })
      
      //js控制弹窗不同信息
      function alertdiv(obj,obj1,obj2){
        obj.onclick = function (){
          div6.style.display = "block";
          alertp1.innerHTML = obj1;
          alerth1.innerHTML = obj2;
        }
      }
      alertdiv4.onclick = function (){
        setTimeout(function (){
          div6.style.display = "none";
        },500)
      }
      alertdiv(syks,"快手","快手号：wenjiayu0942");
      alertdiv(syqq,"QQ","QQ号：1709138965");
      alertdiv(sywx,"微信","微信号：wenjiayu080618");